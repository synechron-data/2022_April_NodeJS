// Import an entire module for side effects only, without importing anything.
// This runs the module's global code, but doesn't actually import any values. 
// require('./lib.js');

// const lib = require('./lib.js');
// // console.log(lib);
// console.log(lib.firstname);
// console.log(lib.lastname);
// console.log(lib.log("Hello from App Module"));

// Import and Use Employee Class

// const lib = require('./lib.js');

// let e1 = new lib.Employee("Manish");
// console.log(e1.getName());
// e1.setName("Abhijeet");
// console.log(e1.getName());

const { Employee } = require('./lib.js');

let e1 = new Employee("Manish");
console.log(e1.getName());
e1.setName("Abhijeet");
console.log(e1.getName());

// var person = { id: 1, name: "Manish" };

// // Object Destructuring
// var { id, name } = person;

// var id = person.id;
// var name = person.name;
