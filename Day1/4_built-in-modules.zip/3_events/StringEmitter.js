const EventEmitter = require('events');

class StringEmitter extends EventEmitter {
    strArr = ["NodeJS", "ReactJS", "Angular", "ExtJS", "jQuery"];

    constructor() {
        super();
        this.run();
    }

    run() {
        setInterval(() => {
            var str = this.strArr[Math.floor(Math.random() * this.strArr.length)];
            this.emit('data', str);         // Publish
        }, 2000);
    }

    pushString(cb) {
        setInterval(() => {
            var str = this.strArr[Math.floor(Math.random() * this.strArr.length)];
            cb(str);
        }, 2000);
    }

    getString() {
        var str = this.strArr[Math.floor(Math.random() * this.strArr.length)];
        return str;
    }
}

module.exports = StringEmitter;