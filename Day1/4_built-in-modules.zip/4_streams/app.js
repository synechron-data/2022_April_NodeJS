// const fs = require('fs');

// // Read the entire file into memory and then callback will be executed
// // fs.readFile('./file1.txt', 'utf-8', (err, data) => {
// //     if (err)
// //         console.log(err);
// //     else
// //         console.log(data);
// // });

// const readStream = fs.createReadStream('./file1.txt', {
//     bufferSize: 4 * 1024
// });

// let fData = "";

// readStream.on('open', () => {
//     console.log("File Opened...");
// });

// readStream.on('error', (err) => {
//     console.log(err);
// });

// readStream.on('end', () => {
//     console.log("File Ended...");
//     console.log(fData);
// });

// readStream.on('data', (chunk) => {
//     fData += chunk;
// });

// ------------------------------------------------------

const fs = require('fs');

const readStream = fs.createReadStream('./file1.txt');
const writeStream = fs.createWriteStream('./file2.txt');

readStream.on('data', (chunk) => {
    writeStream.write(chunk);
});

readStream.on('end', () => {
    console.log("File Copied...");
    readStream.close();
    writeStream.close();
});