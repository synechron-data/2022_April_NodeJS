const DBLogger = require('./DBLogger');
const FileLogger = require('./FileLogger');

module.exports = { DBLogger, FileLogger };