const Logger = require("./Logger");
const logger = new Logger();

module.exports.log = function (message) {
    logger.log(message);
}