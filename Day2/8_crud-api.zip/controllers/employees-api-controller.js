const da = require('../data-access');

exports.getAllEmployees = (req, res, next) => {
    da.getAllEmployees().then(result => {
        res.status(200).json({ data: result, message: "Success, Getting Employees" });
    }, eMsg => {
        res.status(500).json({ data: [], message: "Error, Getting Employees" });
    });
}

exports.getEmployee = (req, res, next) => {
    var id = req.params.empid;
    da.getEmployee(id).then(result => {
        res.status(200).json({ data: result, message: "Success, Getting Employee" });
    }, eMsg => {
        res.status(500).json({ data: [], message: "Error, Getting Employee" });
    });
}

exports.createEmployee = (req, res, next) => {
    var { eid, ename } = req.body;
    var employee = { id: parseInt(eid), name: ename };

    da.insertEmployee(employee).then(result => {
        res.status(201).json({ data: result, message: "Success, Inserting Employee" });
    }, eMsg => {
        res.status(500).json({ data: [], message: "Error, Inserting Employee" });
    });
}

exports.updateEmployee = (req, res, next) => {
    var { eid, ename } = req.body;
    var employee = { id: parseInt(eid), name: ename };

    da.updateEmployee(employee).then(result => {
        res.status(200).json({ data: result, message: "Success, Updating Employee" });
    }, eMsg => {
        res.status(500).json({ data: [], message: "Error, Updating Employee" });
    });
}

exports.deleteEmployee = (req, res, next) => {
    var id = req.params.empid;

    da.deleteEmployee(id).then(_ => {
        res.status(204).json({ data: null, message: "Success, Deleting Employee" });
    }, eMsg => {
        res.status(500).json({ data: [], message: "Error, Deleting Employee" });
    });
}