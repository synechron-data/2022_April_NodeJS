var express = require('express');
var cors = require('cors');

var router = express.Router();

const empApiCtrl = require('../controllers/employees-api-controller');

router.use(cors());

// GET - /api/employees (Get All Employees)
router.get('/', empApiCtrl.getAllEmployees);

// GET - /api/employees/1 (Get Employee by Id)
router.get('/:empid', empApiCtrl.getEmployee);

// POST - /api/employees (Create an Employee)
router.post("/", empApiCtrl.createEmployee);

// PUT - /api/employees/1 (Update an Employee)
router.put('/:empid', empApiCtrl.updateEmployee);

// DELETE - /api/employees/1 (Update an Employee)
router.delete('/:empid', empApiCtrl.deleteEmployee);

module.exports = router;
