const express = require('express');
const router = express.Router();

const empsCtrl = require('../controllers/employees-controller');

router.get("/", empsCtrl.index);

router.get("/details/:empid", empsCtrl.details);

module.exports = router;